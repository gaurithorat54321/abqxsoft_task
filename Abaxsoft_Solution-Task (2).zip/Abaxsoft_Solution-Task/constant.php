<?php
define('dbserver', "localhost");
define('dbuser', "root");
define('dbpass', "");
define('dbname', "abaxsoft_task");
define('base_url','https://'.$_SERVER['HTTP_HOST'].'//');
?>