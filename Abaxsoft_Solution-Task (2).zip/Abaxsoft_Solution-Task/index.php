<?php 
if(isset($_POST['true']))
 {
  
    header("Location:home.php");
         
  }
  else
  {
      $error = "Sorry";
  }
   
?>
<!DOCTYPE html>
<html>
<head>
	<title>
		Welcome
	</title>
<link href="css/style.css" stylesheet" type="text/css" media="all" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-BmbxuPwQa2lc/FVzBcNJ7UAyJxM6wuqIj61tLrc4wSX0szH/Ev+nYRRuWlolflfl" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="css/style.css">
<style type="text/css">
    .bg{
 background-image:url("images/background2.jpg");
 background-repeat: no-repeat;
 background-size:100%;
}
.btn-secondary {
  width: 300px;
  border-radius: 12px;

}
</style>
</head>
<body class="bg">

	<div class="container-fuild bg">
		<div class="row justify-content-center">
		<div class="col-4 mt-5 my-auto frm">
			<h3 class="text-center text-dark">Welcome</h3>
		<form name="start" method="post" action="">
		   <div class="form-group form-check">
		    <input type="hidden" class="" id="chk" value="true" name="true">
		   
		  </div>
		  <button type="submit" class="btn btn-secondary" name="submit value="submit"><h5 class="text-white">Start</h5></button>
		</form>
	</div>
		</div>
	</div>
</body>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.bundle.min.js" integrity="sha384-b5kHyXgcpbZJO/tY9Ul7kGkf1S0CWuKcCD38l8YkeH8z8QjE0GmW1gYU5S9FOnJ0" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.6.0/dist/umd/popper.min.js" integrity="sha384-KsvD1yqQ1/1+IA7gi3P0tyJcT3vR+NdBTt13hSJ2lnve8agRGXTTyNaBYmCR/Nwi" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta2/dist/js/bootstrap.min.js" integrity="sha384-nsg8ua9HAw1y0W1btsyWgBklPnCUAFLuTMS2G72MMONqmOymq585AcH49TLBQObG" crossorigin="anonymous"></script>
</html>
