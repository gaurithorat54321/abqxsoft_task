<?php
require_once('query.php');
 if(!empty($_POST['user_action'])) {
     switch($_POST['user_action']) {
       case 'add':
               $where = 'mobile= "'. strip_tags(trim($_REQUEST['mobile'])).'"';
                 $data = $QueryFire->getAllData('user',$where);
              if(empty($data[0]))
              {
                      $arr['name'] = strip_tags(trim($_REQUEST['name']));
                      $arr['mobile'] = strip_tags(trim($_REQUEST['mobile']));
                      $arr['email'] = strip_tags(trim($_REQUEST['email']));
                      $arr['address'] = strip_tags(trim($_REQUEST['address']));
                      $arr['city'] = strip_tags(trim($_REQUEST['city']));
                      $arr['state'] = strip_tags(trim($_REQUEST['state']));
                         if($QueryFire->insertData("user",$arr))
                         {
                         $msg ='User record added successfully.';
               
                       }else
                       {
                         $msg = 'User record not added.';
               
                       }
                     }
                     else {
                          $msg= "Mobile No already exist ";
                     }
           unset($data);
           break;
           case 'update':
               $arr['name'] = strip_tags(trim($_REQUEST['name']));
               $arr['mobile'] = strip_tags(trim($_REQUEST['mobile']));
               $arr['email'] = strip_tags(trim($_REQUEST['email']));
               $arr['address'] = strip_tags(trim($_REQUEST['address']));
               $arr['city'] = strip_tags(trim($_REQUEST['city']));
               $arr['state'] = strip_tags(trim($_REQUEST['state']));
              if($QueryFire->upDateTable("user",' id='.$_POST['id'],$arr))
             {
               $msg = 'User record updated successfully.';
             }
            else {
               $msg = 'User record not updated .';
             }
           unset($data);
           break;
       case 'delete':
         
           $QueryFire->deleteDataFromTable("user",' id='.$_POST['id']);
           $msg = 'User record deleted successfully.';
           break;
     
     }
   }
 $data = $QueryFire->getAllData('','','select u.id,u.name,u.mobile,u.email,u.address,u.state,c.name as city from user as u left join city as c on c.id=.u.city');
  $cities = $QueryFire->getAllData('city','1=1');
  $states = $QueryFire->getAllData('states','1=1');
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Crud Operation</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta name="viewport" content="width=device-width, initial-scale=1">
  
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <!-- Tempusdominus Bbootstrap 4 -->
  <link rel="stylesheet" href="plugins/tempusdominus-bootstrap-4/css/tempusdominus-bootstrap-4.min.css">
  <!-- iCheck -->
  <link rel="stylesheet" href="plugins/icheck-bootstrap/icheck-bootstrap.min.css">
  <!-- JQVMap -->
  <link rel="stylesheet" href="plugins/jqvmap/jqvmap.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/adminlte.min.css">
  <!-- overlayScrollbars -->
  <link rel="stylesheet" href="plugins/overlayScrollbars/css/OverlayScrollbars.min.css">
  
  <link rel="stylesheet" href="plugins/datatables-bs4/css/dataTables.bootstrap4.min.css">
  <link rel="stylesheet" href="plugins/datatables-buttons/css/buttons.bootstrap4.min.css">
  <link rel="stylesheet" href="plugins/datatables-responsive/css/responsive.bootstrap4.min.css">
 <link href="https://cdn.datatables.net/1.10.16/css/jquery.dataTables.min.css" rel="stylesheet" />
  <link href="https://cdn.datatables.net/buttons/1.5.1/css/buttons.dataTables.min.css" rel="stylesheet" /> 
  <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
  <link rel="stylesheet" type="text/css" href="css/style.css">
  <?= isset($prependScript)?$prependScript:""?>
  <style type="text/css">
    .bg{
 background-image:url("images/background2.jpg");
 background-repeat: no-repeat;
 background-size:100%;
}
.btn-secondary {
  width: 300px;
  border-radius: 12px;

}
</style>
</head>
<body class="bg">
  <!-- Site wrapper -->
  <section class="content-header">
   <div class="container-fluid">
      <div class="row mb-2">
         <div class="col-sm-12">
            <h1>CRUD Operations </h1>
         </div>
         <div class="col-sm-6">
           <button class="btn btn-info text-white dev-add">Add Record</button>
         </div>
      </div>
   </div>
   <!-- /.container-fluid -->
</section>
<section class="content">
   <div class="row">
      <div class="col-12">
         <div class="card">
            <div class="card-body">
               <?php echo !empty($msg)?'<h5 class="text-center text-success">'.$msg.'</h5>':''?>
               <table class="data-table table table-bordered table-striped table-bordered table-hover">
                  <thead>
                     <tr>
                        <th>#</th>
                        <th>Name</th>
                        <th>Mobile</th>
                        <th>Email</th>
                         <th>Address</th>
                         <th>City</th>
                         <th>State</th>
                        <th>Action</th>
                     </tr>
                  </thead>
                  <?php if(!empty($data)) { $cnt=1;
                        foreach($data as $row) { ?>
                     <tr>
                        <td><?php echo $cnt++;?></td>
                        <td class="name"><?php echo ucfirst($row['name']);?></td>
                        <td class="mobile"><?php echo $row['mobile'];?></td>
                        <td class="email"><?php echo $row['email'];?></td>
                        <td class="address"><?php echo ucfirst($row['address']);?></td>
                        <td class="city"><?php echo ucfirst($row['city']);?></td>
                        <td class="state"><?php echo ucfirst($row['state']);?></td>

                        <td>
                           <button class="btn btn-success btn-xs dev-edit mt-1" data-id="<?php echo $row['id'];?>">Edit</button>
                           <button class="btn btn-danger btn-xs dev-delete mt-1" data-id="<?php echo $row['id'];?>">Delete</button>
                        </td>
                     </tr>
                     <?php } } ?>
                  </tbody>
               </table>
            </div>
         </div>
      </div>
   </div>
</section>
<form class="active_inactive-form" method="post">
   <input type="hidden" name="id" />
   <input type="hidden" name="user_action" />
</form>
<div id="add-edit-modal" class="modal fade" role="dialog"  data-backdrop="static">
   <div class="modal-dialog">
      <form method="post" action="" class="add-edit-form" enctype="multipart/form-data">
         <div class="modal-content">
            <div class="modal-header">
               <h4 class="modal-title"></h4>
            </div>
            <div class="modal-body">
               <div class="form-group">
                  <label for="name">Name</label>
                    <input class="form-control nameT" name="name" required placeholder="Enter name" type="text">
                    
                   <label for="mobile">Mobile No:</label>
                  <input class="form-control mobileT" name="mobile" placeholder="Enter mobile no" type="number">
                  <label for="email">Email</label>
                  <input type="email" name="email"  placeholder="Enter email" rows="6" class="form-control  emailT">
                 <label for="address">Address:</label>
                  <input class="form-control addressT" name="address" placeholder="Enter address" type="text">
                 <label for="city">City</label>
                      <select name="city" class="form-control cityT">
                         <option value="">Select city</option>
                            <?php foreach ($cities as $row) { ?>
                              <option value="<?=$row['id'] ?>"><?php echo ucfirst($row['name']) ?></option>
                           <?php }
                           ?>
                       </select>
                        <label for="state">States</label>
                      <select name="state" class="form-control stateT">
                        <option value="">Select State</option>
                            <?php foreach ($states as $row) { ?>
                       <option value="<?=$row['name'] ?>"><?php echo ucfirst($row['name']) ?></option>
                           <?php }
                           ?>
                       </select>
                 
                </div>
               <input type="hidden" name="user_action" class="user_action">
               <input type="hidden" name="id" class="user_id">
            </div>
            <div class="modal-footer">
               <button type="submit" class="btn btn-primary" name="add" >Submit</button>
               <button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
            </div>
         </div>
      </form>
   </div>
</div>
<?php 
   $appendScript = '
     <script>
       $(document).ready(function() {
         var validator = jQuery(".add-edit-form").validate({
             rules: {
            mobile: {
               required:true,
               number:true,
               minlength:10,
               maxlength:10
             },
            name: {
               required:true,
               number:false,
               minlength:3,
              
             },
              city:"required",
              state:"required",
             email: {
               required:true,
               email:true
             }
             
             },
           messages: {
              mobile: {
               required:"Enter mobile no",
               number:"Enter valid mobile no",
               minlength:"Enter valid mobile no",
               maxlength:"Enter valid mobile no"
             },
             name: {
               required:"Enter name",
               number:"Enter valid name",
               minlength:"Enter valid name"
               
             },
              city:"Enter city",
               state:"Enter state",
             email: {
               required:"Enter email",
               email:"Enter valid email"
              
               
             }

            }
          
         });
         jQuery(document).on("click",".dev-add",function(e){
           validator.resetForm();
           jQuery("#add-edit-modal .user_action").val("add");
           jQuery("#add-edit-modal .modal-title").html("Add New Record");
           jQuery("#add-edit-modal").modal("show");
         });
         jQuery(document).on("click",".dev-edit",function(e){
           validator.resetForm();
           jQuery("#add-edit-modal .modal-title").html("Update Record");
           jQuery("#add-edit-modal .user_action").val("update");
           jQuery("#add-edit-modal .user_id").val(jQuery(this).data("id"));
           jQuery("#add-edit-modal .nameT").val(jQuery(this).parents("tr").find(".name").text());
           jQuery("#add-edit-modal .cityT").val(jQuery(this).parents("tr").find(".city").text());
           jQuery("#add-edit-modal .stateT").val(jQuery(this).parents("tr").find(".state").text());
             jQuery("#add-edit-modal .addressT").val(jQuery(this).parents("tr").find(".address").text());
            jQuery("#add-edit-modal .mobileT").val(jQuery(this).parents("tr").find(".mobile").text());
           jQuery("#add-edit-modal .emailT").val(jQuery(this).parents("tr").find(".email").text());
          
           jQuery("#add-edit-modal").modal("show");
         });
         jQuery(document).on("click",".dev-delete",function(e){
             if(jQuery(this).data("id") != "") {
                 var id = jQuery(this).data("id");
                 bootbox.confirm({
                     title: "Are you sure you want to delete this record?",
                     message: "<span class='."'text-danger'".'>All related information will be deleted.</span>",
                     buttons: {
                       confirm: {
                         label: "Yes",
                          className: "btn-success btn-sm"
                       },
                       cancel: {
                         label: "No",
                         className: "btn-danger btn-sm"
                       }
                     },
                     callback: function (result) {
                       if(result) {
                           jQuery(".active_inactive-form input:nth(0)").val(id);
                           jQuery(".active_inactive-form input:nth(1)").val("delete");
                         jQuery(".active_inactive-form").submit();
                       }
                     }
                 });
             }
         });
       });
     </script>';
     ?>
 </body>
<!-- ./wrapper -->
<!-- jQuery -->
<script src="dist/jquery.table2excel.min.js"></script>
<script src="dist/jquery.table2excel.js"></script>-->
<script src="plugins/jquery/jquery.min.js"></script>
<!-- jQuery UI 1.11.4 -->
<script src="plugins/jquery-ui/jquery-ui.min.js"></script>

<!-- Bootstrap 4 -->
<script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- Sparkline -->
<script src="plugins/sparklines/sparkline.js"></script>
<!-- daterangepicker -->
<script src="plugins/moment/moment.min.js"></script>

<!-- Tempusdominus Bootstrap 4 -->
<script src="plugins/tempusdominus-bootstrap-4/js/tempusdominus-bootstrap-4.min.js"></script>

<script src="plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js"></script>

<script src="plugins/select2/js/select2.full.min.js"></script>

<!-- Validation -->
<script src="plugins/jquery-validation/jquery.validate.min.js"></script>
<script src="plugins/jquery-validation/additional-methods.min.js"></script>

<!-- DataTables -->
<script src="plugins/datatables/jquery.dataTables.min.js"></script>
<script src="plugins/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
<script src="plugins/datatables-responsive/js/dataTables.responsive.min.js"></script>
<script src="plugins/datatables-responsive/js/responsive.bootstrap4.min.js"></script>
<script src="plugins/datatables-buttons/js/dataTables.buttons.min.js"></script>
<script src="plugins/datatables-buttons/js/buttons.bootstrap4.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootbox.js/5.4.0/bootbox.min.js"></script>

<script type="text/javascript">
  jQuery(function(){
    if(jQuery(".data-table").length) {
      jQuery(".data-table").DataTable();
    }
  });
</script>
<?= isset($appendScript)?$appendScript:""?>
</body>
</html>
